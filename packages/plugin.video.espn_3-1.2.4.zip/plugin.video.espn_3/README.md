plugin.video.espn_3
===================

Fork of original espn3 addon by bluecop. This one has the non-working settings removed.

Watch full live streaming sporting events and replays on ESPN 3, including football, baseball, cricket, soccer, and basketball events.
This add-on does not support the FULL WatchESPN app. Only ESPN 3 feeds.

If you have trouble with this add-on, please visit the support thread at -- http://forum.kodi.tv/showthread.php?tid=186028
